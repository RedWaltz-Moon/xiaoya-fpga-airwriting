#ifndef __IR_TX_H__
#define __IR_TX_H__
void IR_TX_Init(void) ;
void IR_SendNEC(uint8_t data, uint8_t address);
#endif

